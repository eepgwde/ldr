# -*- coding: utf-8 -*-

__version__ = u"0.1.0"
