* weaves

* singledispatch1

This is a useful function overloading method for objects. It's the same as
@singledispatch but adapted for object methods.

* Singleton

This is a Singleton method for Python.
Most utility methods are vectored through this. The idea is that you can
swap the implementation at runtime by changing the instantiation method.

Typically, logged and threadsafe implementations of _Impl could be provided.

* This file's Emacs file variables

[  Local Variables: ]
[  mode:text ]
[  mode:outline-minor ]
[  mode:auto-fill ]
[  fill-column: 75 ]
[  coding: iso-8859-1-unix ]
[  comment-column:50 ]
[  comment-start: "[  "  ]
[  comment-end:"]" ]
[  End: ]

